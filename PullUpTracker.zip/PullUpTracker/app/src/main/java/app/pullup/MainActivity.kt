package app.pullup

import android.Manifest
import android.graphics.*
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import java.util.concurrent.Executors

class Overlay(c: android.content.Context) : View(c) {
    var barY = 0.3f; var headY: Float? = null; var above = false
    private val line = Paint().apply { color = 0xFFFFD23F.toInt(); strokeWidth = 8f; pathEffect = DashPathEffect(floatArrayOf(30f, 20f), 0f) }
    private val dot = Paint()
    override fun onDraw(cv: Canvas) {
        cv.drawLine(0f, barY * height, width.toFloat(), barY * height, line)
        headY?.let { dot.color = if (above) 0xFF5EE08A.toInt() else Color.WHITE; cv.drawCircle(width / 2f, it * height, 18f, dot) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean { barY = (e.y / height).coerceIn(0.05f, 0.95f); invalidate(); return true }
}

class MainActivity : ComponentActivity() {
    private val tones = listOf("Бип" to ToneGenerator.TONE_PROP_BEEP2, "Подтверждение" to ToneGenerator.TONE_SUP_CONFIRM,
        "Звонок" to ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, "Сигнал" to ToneGenerator.TONE_CDMA_ABBR_ALERT)
    private val names = tones.map { it.first } + "Свой файл"
    private lateinit var overlay: Overlay
    private lateinit var countView: TextView
    private lateinit var spinner: Spinner
    private val tg by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 100) }
    private var custom: Uri? = null
    private var reps = 0
    private var down = true
    private val exec = Executors.newSingleThreadExecutor()
    private var pose: PoseLandmarker? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { contentResolver.takePersistableUriPermission(u, Intent_READ); custom = u; spinner.setSelection(names.lastIndex); playSound() }
    }
    private val askCam = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startCamera() else toast("Нужен доступ к камере") }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun playSound() {
        val i = spinner.selectedItemPosition
        if (i < tones.size) tg.startTone(tones[i].second, 400)
        else custom?.let { MediaPlayer.create(this, it)?.apply { setOnCompletionListener { release() }; start() } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        overlay = Overlay(this)
        countView = TextView(this).apply { textSize = 88f; setTextColor(Color.WHITE); setShadowLayer(12f, 0f, 2f, Color.BLACK); text = "0"; setPadding(32, 8, 0, 0) }
        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                var first = true
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (first) { first = false; return }
                    if (pos == names.lastIndex) pickFile.launch(arrayOf("audio/*")) else playSound()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        val reset = Button(this).apply { text = "Сброс"; setOnClickListener { reps = 0; down = true; countView.text = "0" } }
        val bar = LinearLayout(this).apply {
            setBackgroundColor(0xCC161B22.toInt()); setPadding(24, 16, 24, 16)
            addView(spinner, LinearLayout.LayoutParams(0, -2, 1f)); addView(reset)
        }
        setContentView(FrameLayout(this).apply {
            addView(preview); addView(overlay); addView(countView)
            addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        })
        pose = PoseLandmarker.createFromOptions(this, PoseLandmarker.PoseLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build())
            .setRunningMode(RunningMode.VIDEO).setNumPoses(1).build())
        askCam.launch(Manifest.permission.CAMERA)
        this.preview = preview
    }
    private lateinit var preview: PreviewView

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { img -> analyze(img) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
        val bmp = Bitmap.createBitmap(img.toBitmap(), 0, 0, img.width, img.height, m, true)
        val res = pose?.detectForVideo(BitmapImageBuilder(bmp).build(), System.currentTimeMillis())
        img.close()
        val nose = res?.landmarks()?.firstOrNull()?.firstOrNull()
        runOnUiThread {
            if (nose == null) { overlay.headY = null; overlay.invalidate(); return@runOnUiThread }
            val y = nose.y()
            overlay.headY = y
            overlay.above = y < overlay.barY
            if (down && y < overlay.barY) { down = false; reps++; countView.text = "$reps"; playSound() }
            else if (!down && y > overlay.barY + 0.07f) down = true
            overlay.invalidate()
        }
    }

    override fun onDestroy() { super.onDestroy(); pose?.close(); exec.shutdown(); tg.release() }
}
private const val Intent_READ = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
