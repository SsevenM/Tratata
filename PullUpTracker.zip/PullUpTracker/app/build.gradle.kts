plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.pullup"; compileSdk = 34
    defaultConfig { applicationId = "app.pullup"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    val cx = "1.3.4"
    implementation("androidx.camera:camera-core:$cx")
    implementation("androidx.camera:camera-camera2:$cx")
    implementation("androidx.camera:camera-lifecycle:$cx")
    implementation("androidx.camera:camera-view:$cx")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}
// Скачивает модель позы в assets при первой сборке
val downloadModel by tasks.registering {
    val f = file("src/main/assets/pose_landmarker_lite.task")
    outputs.file(f)
    doLast {
        if (!f.exists()) {
            f.parentFile.mkdirs()
            uri("https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task").toURL()
                .openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadModel) }
